# Lab 6

## Help Received

Please document any help you received in completing this lab. Note that the what you submit should be your own work. Refer to the syllabus for more details. 

[ANSWER HERE]

## Describe your work


## Part 1: 

Provide a paragraph (or more) description of your redesign of DotChaser to be more object oriented and ploymorphic.

[ANSWER HERE]

## Part 2:

Provide a paragraph (or more) explaining how your new OOP design makes adding new types of Things easy

[ANSWER HERE]

Provide a paragraph (or more) explaining exactly where in your program there is a polymorphic function call, and how that plays an essential role in the program functioning properly.

## Part 3:

Create a UML diagram for your Thing types. Add it as `UML.png` and link it below to display 

![](/path/to/image/in/your/repo/to/UML.png)

## Extra Credit:

Add another paragraph in describing your extra credit extension to the Thing object model.

[ANSWER HERE]

Include a screenshot of your plotter below.

![](/path/to/image/in/your/repo/to/plotter/screenshot)

